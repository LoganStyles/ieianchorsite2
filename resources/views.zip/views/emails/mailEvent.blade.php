<h3>New RSA Registration</h3>
<p>Below are the details of a client who registered from our website, kindly follow up</p>
<div>
    <ul>
        <li><strong> Email:</strong> <span>{{$client_email}}</span></li>
        <li><strong> Name:</strong> <span>{{$clientname}}</span></li>
        <li><strong> Phone:</strong> <span>{{$phone}}</span></li>
        <li><strong> State:</strong> <span>{{$states}}</span></li>
    </ul>
</div>

