<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <title>IEI Anchor Pension Managers Limited | @yield('title') </title>
        @include('includes.header_site')        
        
        @yield('content')
        @include('includes.footer_site')