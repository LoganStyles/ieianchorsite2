<?php

namespace App\Http\Controllers;

use App\Articleimage;
use Illuminate\Http\Request;

class ArticleimageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Articleimage  $articleimage
     * @return \Illuminate\Http\Response
     */
    public function show(Articleimage $articleimage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Articleimage  $articleimage
     * @return \Illuminate\Http\Response
     */
    public function edit(Articleimage $articleimage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Articleimage  $articleimage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Articleimage $articleimage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Articleimage  $articleimage
     * @return \Illuminate\Http\Response
     */
    public function destroy(Articleimage $articleimage)
    {
        //
    }
}
