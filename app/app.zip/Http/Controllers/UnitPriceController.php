<?php

namespace App\Http\Controllers;

use App\Unit_price;
use Illuminate\Http\Request;

class UnitPriceController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Unit_price  $unit_price
     * @return \Illuminate\Http\Response
     */
    public function show(Unit_price $unit_price)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Unit_price  $unit_price
     * @return \Illuminate\Http\Response
     */
    public function edit(Unit_price $unit_price)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Unit_price  $unit_price
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Unit_price $unit_price)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Unit_price  $unit_price
     * @return \Illuminate\Http\Response
     */
    public function destroy(Unit_price $unit_price)
    {
        //
    }
}
