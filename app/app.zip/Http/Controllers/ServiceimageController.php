<?php

namespace App\Http\Controllers;

use App\Serviceimage;
use Illuminate\Http\Request;

class ServiceimageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Serviceimage  $serviceimage
     * @return \Illuminate\Http\Response
     */
    public function show(Serviceimage $serviceimage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Serviceimage  $serviceimage
     * @return \Illuminate\Http\Response
     */
    public function edit(Serviceimage $serviceimage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Serviceimage  $serviceimage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Serviceimage $serviceimage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Serviceimage  $serviceimage
     * @return \Illuminate\Http\Response
     */
    public function destroy(Serviceimage $serviceimage)
    {
        //
    }
}
