<?php

namespace App\Http\Controllers;

use App\Faqcat;
use Illuminate\Http\Request;

class FaqcatController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Faqcat  $faqcat
     * @return \Illuminate\Http\Response
     */
    public function show(Faqcat $faqcat)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Faqcat  $faqcat
     * @return \Illuminate\Http\Response
     */
    public function edit(Faqcat $faqcat)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Faqcat  $faqcat
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Faqcat $faqcat)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Faqcat  $faqcat
     * @return \Illuminate\Http\Response
     */
    public function destroy(Faqcat $faqcat)
    {
        //
    }
}
