<?php

namespace App\Http\Controllers;

use App\Newsitemimage;
use Illuminate\Http\Request;

class NewsitemimageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Newsitemimage  $newsitemimage
     * @return \Illuminate\Http\Response
     */
    public function show(Newsitemimage $newsitemimage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Newsitemimage  $newsitemimage
     * @return \Illuminate\Http\Response
     */
    public function edit(Newsitemimage $newsitemimage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Newsitemimage  $newsitemimage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Newsitemimage $newsitemimage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Newsitemimage  $newsitemimage
     * @return \Illuminate\Http\Response
     */
    public function destroy(Newsitemimage $newsitemimage)
    {
        //
    }
}
