<?php

namespace App\Http\Controllers;

use App\Bannerimage;
use Illuminate\Http\Request;

class BannerimageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Bannerimage  $bannerimage
     * @return \Illuminate\Http\Response
     */
    public function show(Bannerimage $bannerimage)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Bannerimage  $bannerimage
     * @return \Illuminate\Http\Response
     */
    public function edit(Bannerimage $bannerimage)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Bannerimage  $bannerimage
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Bannerimage $bannerimage)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Bannerimage  $bannerimage
     * @return \Illuminate\Http\Response
     */
    public function destroy(Bannerimage $bannerimage)
    {
        //
    }
}
