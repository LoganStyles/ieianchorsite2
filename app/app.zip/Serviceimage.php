<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Serviceimage extends Model
{
    //
}
