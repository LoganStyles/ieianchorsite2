<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Boardimage extends Model
{
    //
}
