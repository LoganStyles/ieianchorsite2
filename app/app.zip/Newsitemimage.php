<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Newsitemimage extends Model
{
    //
}
