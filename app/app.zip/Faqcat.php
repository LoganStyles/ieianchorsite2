<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Faqcat extends Model
{
    //
}
