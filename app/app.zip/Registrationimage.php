<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Registrationimage extends Model
{
    //
}
